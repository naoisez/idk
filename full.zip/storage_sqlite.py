import sqlite3
from datetime import datetime

DB_FILE = 'chatbot.db'

# --- Table creation ---
def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS chats (
            id TEXT PRIMARY KEY,
            customerName TEXT,
            customerEmail TEXT,
            customerPhone TEXT,
            status TEXT,
            lastMessage TEXT,
            messageCount INTEGER,
            createdAt TEXT,
            lastActivity TEXT,
            satisfaction REAL
        )''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS messages (
            id TEXT PRIMARY KEY,
            chat_id TEXT,
            sender TEXT,
            content TEXT,
            timestamp TEXT,
            status TEXT,
            FOREIGN KEY(chat_id) REFERENCES chats(id)
        )''')
        # Bot config table
        cursor.execute('''CREATE TABLE IF NOT EXISTS bot_config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            bot_name TEXT,
            initial_message TEXT
        )''')
        # Ensure a row exists
        cursor.execute('INSERT OR IGNORE INTO bot_config (id, bot_name, initial_message) VALUES (1, ?, ?)', ("AI Assistant", "Welcome to <business>! How can I assist you today?"))
        conn.commit()

init_db()

# --- Storage functions ---
def add_chat(chat):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT OR REPLACE INTO chats (id, customerName, customerEmail, customerPhone, status, lastMessage, messageCount, createdAt, lastActivity, satisfaction)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (
                chat['id'],
                chat.get('customerName'),
                chat.get('customerEmail'),
                chat.get('customerPhone'),
                chat.get('status'),
                chat.get('lastMessage'),
                chat.get('messageCount'),
                chat.get('createdAt'),
                chat.get('lastActivity'),
                chat.get('satisfaction')
            )
        )
        conn.commit()

def add_message(chat_id, message):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO messages (id, chat_id, sender, content, timestamp, status)
            VALUES (?, ?, ?, ?, ?, ?)''',
            (
                message['id'],
                chat_id,
                message.get('sender'),
                message.get('content'),
                message.get('timestamp'),
                message.get('status')
            )
        )
        conn.commit()

def update_chat(chat_id, updates):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        fields = []
        values = []
        for k, v in updates.items():
            fields.append(f"{k} = ?")
            values.append(v)
        values.append(chat_id)
        sql = f"UPDATE chats SET {', '.join(fields)} WHERE id = ?"
        cursor.execute(sql, values)
        conn.commit()

def get_chat_by_id(chat_id):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM chats WHERE id = ?', (chat_id,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            return dict(zip(columns, row))
        return None

def get_chats():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM chats')
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        return [dict(zip(columns, row)) for row in rows]

def get_messages():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM messages')
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        # Group by chat_id
        messages = {}
        for row in rows:
            msg = dict(zip(columns, row))
            chat_id = msg['chat_id']
            if chat_id not in messages:
                messages[chat_id] = []
            messages[chat_id].append(msg)
        return messages

def get_messages_for_chat(chat_id):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM messages WHERE chat_id = ? ORDER BY timestamp', (chat_id,))
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        return [dict(zip(columns, row)) for row in rows]

def set_chat_satisfaction(chat_id, score):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('UPDATE chats SET satisfaction = ? WHERE id = ?', (score, chat_id))
        conn.commit()

def get_bot_name():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT bot_name FROM bot_config WHERE id = 1')
        row = cursor.fetchone()
        return row[0] if row and row[0] else "AI Assistant"

def set_bot_name(name):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('UPDATE bot_config SET bot_name = ? WHERE id = 1', (name,))
        conn.commit()

def get_initial_message():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT initial_message FROM bot_config WHERE id = 1')
        row = cursor.fetchone()
        return row[0] if row and row[0] else "Welcome to <business>! How can I assist you today?"

def set_initial_message(msg):
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('UPDATE bot_config SET initial_message = ? WHERE id = 1', (msg,))
        conn.commit() 