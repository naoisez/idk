from fastapi import FastAPI, Request, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from main import agent_executor, parser
import json
from datetime import datetime
import uuid
import os
from storage_sqlite import add_chat, add_message, get_chat_by_id, update_chat, get_chats, get_messages_for_chat, set_chat_satisfaction, get_messages, get_bot_name, set_bot_name, get_initial_message, set_initial_message
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse
import tempfile
from fastapi.responses import PlainTextResponse
from collections import Counter
import math

app = FastAPI()

# Allow CORS for local frontend development
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://smegersai.com",
        "https://dashboard.smegersai.com"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/chat")
async def chat(request: Request):
    data = await request.json()
    query = data.get("query", "")
    chat_id = data.get("chat_id")
    customer_name = data.get("customerName", "Anonymous")
    customer_email = data.get("customerEmail", "anonymous@example.com")
    customer_phone = data.get("customerPhone")
    now = datetime.utcnow().isoformat()

    # If no chat_id, create a new chat session
    if not chat_id:
        chat_id = str(uuid.uuid4())
        chat_obj = {
            "id": chat_id,
            "customerName": customer_name,
            "customerEmail": customer_email,
            "customerPhone": customer_phone,
            "status": "active",
            "lastMessage": query,
            "messageCount": 1,
            "createdAt": now,
            "lastActivity": now
        }
        add_chat(chat_obj)
    else:
        chat_obj = get_chat_by_id(chat_id)
        if chat_obj:
            update_chat(chat_id, {
                "lastMessage": query,
                "lastActivity": now,
                "messageCount": chat_obj.get("messageCount", 0) + 1
            })
        else:
            # If chat_id is provided but not found, create new
            chat_obj = {
                "id": chat_id,
                "customerName": customer_name,
                "customerEmail": customer_email,
                "customerPhone": customer_phone,
                "status": "active",
                "lastMessage": query,
                "messageCount": 1,
                "createdAt": now,
                "lastActivity": now
            }
            add_chat(chat_obj)

    # Store user message
    user_message = {
        "id": str(uuid.uuid4()),
        "sender": "user",
        "content": query,
        "timestamp": now,
        "status": "sent"
    }
    add_message(chat_id, user_message)

    # Get bot response
    raw_response = agent_executor.invoke({"query": query})
    output = raw_response.get("output")
    if output is not None:
        structured_response = parser.parse(output)
        bot_message = {
            "id": str(uuid.uuid4()),
            "sender": "bot",
            "content": structured_response.answer,
            "timestamp": datetime.utcnow().isoformat(),
            "status": "sent"
        }
        add_message(chat_id, bot_message)
        # Pass request_user_info to frontend
        return {"chat_id": chat_id, **structured_response.model_dump()}
    else:
        return {"chat_id": chat_id, "error": "No output found in response"}

# --- New Endpoints for Dashboard Integration ---

@app.get("/chats")
def list_chats():
    """Return all chat sessions."""
    return get_chats()

@app.get("/chats/{chat_id}/messages")
def get_chat_messages(chat_id: str):
    """Return all messages for a given chat."""
    messages = get_messages_for_chat(chat_id)
    if messages is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    return messages

@app.post("/chats/{chat_id}/message")
async def add_chat_message(chat_id: str, request: Request):
    """Add a message to a chat (user or bot)."""
    data = await request.json()
    sender = data.get("sender", "user")
    content = data.get("content", "")
    status = data.get("status", "sent")
    now = datetime.utcnow().isoformat()
    message = {
        "id": str(uuid.uuid4()),
        "sender": sender,
        "content": content,
        "timestamp": now,
        "status": status
    }
    add_message(chat_id, message)
    # Optionally update chat last message/activity
    update_chat(chat_id, {"lastMessage": content, "lastActivity": now})
    return {"success": True, "message": message}

@app.post("/chats/{chat_id}/resolve")
def resolve_chat(chat_id: str):
    update_chat(chat_id, {"status": "resolved"})
    return {"success": True}

@app.get("/analytics")
def get_analytics():
    """Return total chats, total messages, average response time, average satisfaction, and peak hours."""
    chats = get_chats()
    messages_data = get_messages()
    
    # Total chats and messages
    total_chats = len(chats)
    total_messages = sum(len(msgs) for msgs in messages_data.values())

    # Average satisfaction score
    satisfaction_scores = [chat.get("satisfaction") for chat in chats if chat.get("satisfaction") is not None]
    avg_satisfaction = round(sum(satisfaction_scores) / len(satisfaction_scores), 2) if satisfaction_scores else None

    # Average response time (user -> next bot)
    response_times = []
    for chat_id, msgs in messages_data.items():
        # Sort messages by timestamp
        msgs_sorted = sorted(msgs, key=lambda m: m["timestamp"])
        for i, msg in enumerate(msgs_sorted):
            if msg["sender"] == "user":
                # Find next bot message
                for j in range(i+1, len(msgs_sorted)):
                    if msgs_sorted[j]["sender"] == "bot":
                        t1 = datetime.fromisoformat(msg["timestamp"])
                        t2 = datetime.fromisoformat(msgs_sorted[j]["timestamp"])
                        diff = (t2 - t1).total_seconds()
                        if diff >= 0:
                            response_times.append(diff)
                        break
    avg_response_time = round(sum(response_times) / len(response_times), 2) if response_times else None

    # Peak hours (hour of day with most messages)
    hour_counts = Counter()
    for msgs in messages_data.values():
        for msg in msgs:
            try:
                hour = datetime.fromisoformat(msg["timestamp"]).hour
                hour_counts[hour] += 1
            except Exception:
                continue
    if hour_counts:
        max_count = max(hour_counts.values())
        peak_hours = [hour for hour, count in hour_counts.items() if count == max_count]
    else:
        peak_hours = []

    return {
        "total_chats": total_chats,
        "total_messages": total_messages,
        "avg_response_time": avg_response_time,
        "avg_satisfaction": avg_satisfaction,
        "peak_hours": peak_hours
    }

@app.get("/chats/{chat_id}/export")
def export_chat(chat_id: str):
    """Export all messages for a chat as a downloadable JSON file, with contact info at the top."""
    messages = get_messages_for_chat(chat_id)
    if messages is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    chat = get_chat_by_id(chat_id)
    contact_info = {
        "customerName": chat.get("customerName", ""),
        "customerEmail": chat.get("customerEmail", ""),
        "customerPhone": chat.get("customerPhone", "")
    } if chat else {}
    export_data = {
        "contact_info": contact_info,
        "messages": messages
    }
    with tempfile.NamedTemporaryFile(delete=False, mode='w', encoding='utf-8', suffix='.json') as tmp:
        json.dump(export_data, tmp, indent=2, ensure_ascii=False)
        tmp_path = tmp.name
    return FileResponse(tmp_path, filename=f"chat_{chat_id}_export.json", media_type='application/json')

@app.get("/chats/{chat_id}/export-txt")
def export_chat_txt(chat_id: str):
    """Export all messages for a chat as a human-readable plain text file, with contact info at the top."""
    messages = get_messages_for_chat(chat_id)
    if messages is None:
        raise HTTPException(status_code=404, detail="Chat not found")
    chat = get_chat_by_id(chat_id)
    contact_lines = []
    if chat:
        contact_lines.append(f"Name: {chat.get('customerName', '')}")
        contact_lines.append(f"Email: {chat.get('customerEmail', '')}")
        contact_lines.append(f"Phone: {chat.get('customerPhone', '')}")
        contact_lines.append("")
    # Format messages as human-readable text
    lines = []
    for msg in messages:
        time = msg.get("timestamp", "")
        sender = msg.get("sender", "user").capitalize()
        content = msg.get("content", "")
        lines.append(f"[{time}] {sender}: {content}")
    text = "\n".join(contact_lines + lines)
    return PlainTextResponse(text, headers={
        "Content-Disposition": f"attachment; filename=chat_{chat_id}_export.txt"
    })

@app.post("/chats/{chat_id}/user-info")
async def update_user_info(chat_id: str, data: dict = Body(...)):
    name = data.get("customerName")
    email = data.get("customerEmail")
    phone = data.get("customerPhone")
    updates = {}
    if name:
        updates["customerName"] = name
    if email:
        updates["customerEmail"] = email
    if phone:
        updates["customerPhone"] = phone
    if updates:
        update_chat(chat_id, updates)
    # LLM acknowledgement
    user_info_str = f"Name: {name or ''}, Email: {email or ''}, Phone: {phone or ''}"
    ack_prompt = f"The user has just submitted their contact information: {user_info_str}. Please acknowledge this and offer further assistance."
    from main import agent_executor, parser
    raw_response = agent_executor.invoke({"query": ack_prompt})
    output = raw_response.get("output")
    if output is not None:
        structured_response = parser.parse(output)
        from datetime import datetime
        import uuid
        bot_message = {
            "id": str(uuid.uuid4()),
            "sender": "bot",
            "content": structured_response.answer,
            "timestamp": datetime.utcnow().isoformat(),
            "status": "sent"
        }
        from storage_sqlite import add_message
        add_message(chat_id, bot_message)
        return {"success": True, "bot_message": bot_message["content"]}
    else:
        return {"success": True, "bot_message": "Thank you for providing your information! How can I assist you further?"}

@app.post("/chats/{chat_id}/satisfaction")
def set_satisfaction(chat_id: str, data: dict = Body(...)):
    score = data.get("score")
    if not isinstance(score, int) or not (1 <= score <= 5):
        raise HTTPException(status_code=400, detail="Score must be an integer between 1 and 5.")
    set_chat_satisfaction(chat_id, score)
    return {"success": True}

@app.get("/bot-config")
def get_bot_config():
    return {"bot_name": get_bot_name(), "initial_message": get_initial_message()}

@app.post("/bot-config")
def update_bot_config(data: dict = Body(...)):
    name = data.get("bot_name")
    initial_message = data.get("initial_message")
    if name is not None:
        if not isinstance(name, str) or not name.strip():
            raise HTTPException(status_code=400, detail="Invalid bot_name")
        set_bot_name(name)
    if initial_message is not None:
        if not isinstance(initial_message, str) or not initial_message.strip():
            raise HTTPException(status_code=400, detail="Invalid initial_message")
        set_initial_message(initial_message)
    return {"success": True, "bot_name": get_bot_name(), "initial_message": get_initial_message()}