import json
import os
from storage_sqlite import add_chat, add_message, get_chats, get_messages_for_chat

CHATS_FILE = 'chats.json'
MESSAGES_FILE = 'messages.json'

# Load JSON data
if not os.path.exists(CHATS_FILE) or not os.path.exists(MESSAGES_FILE):
    print('chats.json or messages.json not found. Migration aborted.')
    exit(1)

with open(CHATS_FILE, 'r', encoding='utf-8') as f:
    chats = json.load(f)

with open(MESSAGES_FILE, 'r', encoding='utf-8') as f:
    messages = json.load(f)

# Migrate chats
existing_chats = {c['id'] for c in get_chats()}
chat_count = 0
for chat in chats:
    if chat['id'] not in existing_chats:
        add_chat(chat)
        chat_count += 1

# Migrate messages
msg_count = 0
for chat_id, msg_list in messages.items():
    existing_msgs = {m['id'] for m in get_messages_for_chat(chat_id)}
    for msg in msg_list:
        if msg['id'] not in existing_msgs:
            add_message(chat_id, msg)
            msg_count += 1

print(f"Migration complete. {chat_count} chats and {msg_count} messages migrated to SQLite.") 