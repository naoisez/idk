# Glow Chat Widget

A modern, production-ready AI chatbot widget built with React and Tailwind CSS, designed to be embedded on any website and powered by a FastAPI backend.

## Features
- Sleek, customizable chat widget UI
- Responsive and mobile-friendly
- Connects to your own AI backend (FastAPI)
- Easy to embed on any website
- Ready for business use

## Prerequisites
- Node.js (v16+ recommended)
- Python 3.9+

## Backend Setup (FastAPI)
1. Install Python dependencies:
   ```sh
   pip install -r requirements.txt
   ```
2. Start the FastAPI server:
   ```sh
   uvicorn api:app --reload
   ```
   The backend will run at [http://localhost:8000](http://localhost:8000).

## Frontend Setup (Glow Chat Widget)
1. Install dependencies:
   ```sh
   cd chat
   npm install
   ```
2. Start the development server:
   ```sh
   npm run dev
   ```
   The frontend will run at [http://localhost:5173](http://localhost:5173) (or as shown in your terminal).

## Embedding the Widget
- Build the widget for production:
  ```sh
  npm run build
  ```
- Copy the contents of the `dist/` folder to your web server or integrate as a static asset.
- To embed the widget on another website, you can:
  1. Host the built JS/CSS files.
  2. Add a `<script src="/path/to/widget.js"></script>` and a `<div id="glow-chat-widget"></div>` to the target site.
  3. Mount the widget to the div in your JS entry point.

## Customization
- Edit `src/components/ChatWidget.tsx` and `src/components/ChatInterface.tsx` for UI/behavior changes.
- Tailwind CSS makes it easy to adjust styles and themes.

## Connecting to Your Backend
- The widget sends chat messages to `http://localhost:8000/chat` by default.
- For production, update the API URL in `ChatInterface.tsx` to your deployed backend endpoint.

## For Businesses
- This widget is ready to be embedded on your site for customer support, lead capture, and more.
- Contact us for custom integrations or white-label solutions.

---

**Enjoy your modern AI chat widget!** 