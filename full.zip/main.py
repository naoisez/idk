from dotenv import load_dotenv
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain.agents import create_tool_calling_agent, AgentExecutor
import json

load_dotenv()

# --- Knowledge Base Tool ---
def load_knowledge_base():
    with open("knowledge_base.json", "r", encoding="utf-8") as f:
        return json.load(f)

def knowledge_base_tool(query: str) -> dict:
    kb = load_knowledge_base()
    # Use the LLM to select the best answer from the KB
    llm = ChatOpenAI(model="gpt-3.5-turbo")
    prompt = (
        "You are a professional and super friendly customer support assistant for Smegers AI.\n\n"
        "You will be given:\n"
        "- A list of knowledge base entries (each with raw factual info)\n"
        "- A user's question\n\n"
        "Your task is to:\n"
        "1. Identify the most relevant entry (if any) from the knowledge base.\n"
        "2. Rewrite the raw content into a friendly, helpful, and professional customer support response.\n"
        "3. If no entry is relevant, say you don’t know and politely offer help another way.\n\n"
        "Keep the tone warm, polite, and helpful. Be concise, clear, and don’t repeat the question.\n"
        "Only use the knowledge base facts to generate the answer. Do not make up information.\n\n"
        f"Knowledge Base:\n{json.dumps(kb, indent=2, ensure_ascii=False)}\n\n"
        f"User Question: {query}\n\n"
        "Respond in this exact JSON format:\n"
        "{\n"
        '  "question": "<relevant topic from KB or repeat user question>",\n'
        '  "answer": "<friendly, rewritten customer support answer>",\n'
        '  "related_articles": ["<optional links from KB, or empty list>"]\n'
        "}"
    )
    response = llm.invoke(prompt)
    # Ensure response.content is a string for json.loads
    content = response.content
    if isinstance(content, list):
        content = " ".join(str(x) for x in content)
    try:
        return json.loads(content)
    except Exception:
        return {
            "question": query,
            "answer": "I'm sorry, I couldn't find any relevant information. Would you like help with something else?",
            "related_articles": []
        }

# --- Tool Wrapper for LangChain ---
from langchain.tools import tool

@tool
def kb_search(query: str) -> str:
    """Searches the knowledge base for an answer to the user's question."""
    result = knowledge_base_tool(query)
    return json.dumps(result)

# --- Response Model ---
class SupportResponse(BaseModel):
    question: str
    answer: str
    related_articles: list[str]
    tools_used: list[str]
    request_user_info: bool = False

llm = ChatOpenAI(model="gpt-3.5-turbo")
parser = PydanticOutputParser(pydantic_object=SupportResponse)

prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
            You are a super friendly and empathetic customer support assistant. 
            Always greet the user warmly, answer their question as helpfully as possible using the knowledge base tool, 
            and express willingness to assist further. If you don't know the answer, apologize and offer to help in another way.
            Be concise, clear, and positive in your responses.
            If the user's question is about booking, scheduling, or meeting (e.g., requests to book, schedule, or arrange a meeting), set 'request_user_info' to true in your output. Otherwise, set it to false.
            Wrap your output in this format and provide no other text:\n{format_instructions}
            """,
        ),
        ("placeholder", "{chat_history}"),
        ("human", "{query}"),
        ("placeholder", "{agent_scratchpad}"),
    ]
).partial(format_instructions=parser.get_format_instructions())

tools = [kb_search]
agent = create_tool_calling_agent(
    llm=llm,
    prompt=prompt,
    tools=tools
)

agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

if __name__ == "__main__":
    query = input("Welcome to <business>! How can I assist you today? ")
    raw_response = agent_executor.invoke({"query": query})

    try:
        output = raw_response.get("output")
        if output is not None:
            structured_response = parser.parse(output)
            print(json.dumps(structured_response.model_dump(), indent=2, ensure_ascii=False))
        else:
            print("No output found in response:", raw_response)
    except Exception as e:
        print("Error parsing response", e, "Raw Response - ", raw_response)